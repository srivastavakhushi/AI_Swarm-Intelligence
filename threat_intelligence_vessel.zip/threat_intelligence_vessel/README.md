# Maritime Threat Intelligence & Oceanographic Subsystem

Self-contained module providing maritime threat intelligence, piracy registers, live tidal prediction telemetry, and AI threat assessment for the Strait of Malacca and global shipping corridors.

---

## 📁 Package Contents

| File | Description |
| :--- | :--- |
| `imo_piracy_service.py` | Official January–July 2026 IMO & ReCAAP-ISC verified piracy and armed robbery dataset (41 verified incidents with coordinates, narrative, vessel details, consequences, and response). |
| `worldtides_service.py` | WorldTides REST API v3 integration engine with caching, astronomical harmonic fallback, and 7 key monitoring stations. |
| `worldtides_key.txt` | Pre-configured permanent WorldTides API key. |
| `risk_classifier_ai.py` | Machine Learning Random Forest classifier predicting maritime risk levels based on vessel speed, distance to coast, and attack clusters. |
| `pirate_attacks.csv` | Historical piracy attack dataset used for training and risk modeling. |
| `threat_intel_server.py` | Standalone FastAPI microservice exposing all threat intelligence endpoints. |
| `index.html` | Standalone tactical GIS web dashboard for inspecting incidents, dossiers, and map telemetry. |

---

## 🚀 Quick Start (Standalone Execution)

### 1. Install Dependencies
```bash
pip install fastapi uvicorn pydantic requests
# Optional for AI risk classifier:
pip install scikit-learn pandas numpy
```

### 2. Start the Threat Intelligence Server
```bash
python threat_intel_server.py
```
Or with Uvicorn:
```bash
uvicorn threat_intel_server:app --reload --port 8080
```

### 3. Open Interactive API Documentation
Open your browser to:
- **Swagger Docs:** `http://127.0.0.1:8080/docs`
- **Interactive UI:** Open `index.html` directly or serve via any static server.

---

## 📡 REST API Endpoints

- `GET /api/threats/imo-2026` — Returns all 41 IMO 2026 incidents with full coordinates and KPI statistics.
- `GET /api/threats/imo-2026/{incident_id}` — Retrieves detailed incident dossier by ID.
- `GET /api/threats/imo-2026/filter?month=June&region=Malacca` — Filters incidents by month, maritime sector, or severity.
- `GET /api/tides?station=singapore` — Pulls live tidal heights, extremes, and 24h predictions for a station.
- `GET /api/tides/stations` — Lists all pre-configured monitoring stations.
- `GET /api/tides/config` — Checks active API key status and operational mode.
- `POST /api/threats/ai-predict` — Runs ML risk classification on coordinates, speed, and coast distance.
