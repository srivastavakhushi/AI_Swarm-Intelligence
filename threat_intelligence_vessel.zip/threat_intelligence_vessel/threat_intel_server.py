"""
Standalone Threat Intelligence & Oceanographic Microservice API
--------------------------------------------------------------
Provides REST API endpoints for:
- IMO 2026 Verified Piracy & Armed Robbery Incidents (Jan - Jul 2026)
- WorldTides REST API v3 Integration & Real-Time Tidal Heights
- AI Machine Learning Maritime Threat Risk Assessment
"""

import os
from typing import Optional
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

import imo_piracy_service as _imo
import worldtides_service as _wt
from worldtides_service import (
    get_worldtides_api_key,
    set_worldtides_api_key,
    test_worldtides_connection,
)

# The service modules expose slightly different function names than this server
# expects, so these small adapters connect the two.


def get_imo_2026_incidents():
    return _imo.get_imo_2026_incidents()["incidents"]


def get_imo_incident_by_id(incident_id):
    for inc in _imo.IMO_2026_INCIDENTS:
        if inc["id"].lower() == incident_id.lower():
            return inc
    return None


def get_imo_summary_kpi():
    d = _imo.get_imo_2026_incidents()
    return {k: d[k] for k in ("critical_count", "high_count", "medium_count", "low_count", "hotspots")}


def filter_imo_incidents(month=None, region=None, severity=None):
    return _imo.get_imo_2026_incidents(month=month, region=region, severity=severity)["incidents"]


def get_tide_data_for_station(station_id="singapore", override_api_key=None):
    return _wt.get_tide_data(station_key=station_id, api_key=override_api_key)


def get_all_predefined_stations():
    return _wt.get_all_stations_summary()


# Copernicus Marine (currents, waves, wind) and Open-Meteo (weather)
from copernicus_service import router as ocean_router
try:
    from weather_service import router as weather_router
except ImportError:
    weather_router = None

try:
    from risk_classifier_ai import train_model, predict_risk
    AI_AVAILABLE = True
except Exception:
    AI_AVAILABLE = False

app = FastAPI(
    title="Maritime Threat Intelligence & Oceanographic API",
    description="Microservice for IMO 2026 Piracy Incident Register, WorldTides Live Telemetry, and AI Risk Prediction",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


app.include_router(ocean_router)
if weather_router:
    app.include_router(weather_router)


class TideConfigBody(BaseModel):
    api_key: str


class RiskPredictBody(BaseModel):
    latitude: float
    longitude: float
    distance_to_coast_km: Optional[float] = 20.0
    vessel_speed_knots: Optional[float] = 14.0


@app.get("/")
def root():
    return {
        "service": "Maritime Threat Intelligence & Oceanographic System",
        "status": "online",
        "endpoints": [
            "/api/threats/imo-2026",
            "/api/threats/imo-2026/{incident_id}",
            "/api/threats/imo-2026/filter",
            "/api/tides",
            "/api/tides/stations",
            "/api/tides/config",
            "/api/threats/ai-predict"
        ]
    }


# =============================================================================
# IMO 2026 PIRACY INTELLIGENCE ENDPOINTS
# =============================================================================
@app.get("/api/threats/imo-2026")
def api_get_imo_threats():
    incidents = get_imo_2026_incidents()
    summary = get_imo_summary_kpi()
    return {
        "status": "success",
        "total_count": len(incidents),
        "summary": summary,
        "incidents": incidents
    }


@app.get("/api/threats/imo-2026/filter")
def api_filter_imo_threats(
    month: Optional[str] = None,
    region: Optional[str] = None,
    severity: Optional[str] = None
):
    results = filter_imo_incidents(month=month, region=region, severity=severity)
    return {
        "status": "success",
        "count": len(results),
        "incidents": results
    }


@app.get("/api/threats/imo-2026/{incident_id}")
def api_get_imo_incident_detail(incident_id: str):
    inc = get_imo_incident_by_id(incident_id)
    if not inc:
        return JSONResponse({"error": f"Incident '{incident_id}' not found"}, status_code=404)
    return {"status": "success", "incident": inc}


# =============================================================================
# WORLDTIDES LIVE OCEANOGRAPHIC API ENDPOINTS
# =============================================================================
@app.get("/api/tides")
def api_get_tides(station: Optional[str] = "singapore", api_key: Optional[str] = None):
    data = get_tide_data_for_station(station_id=station, override_api_key=api_key)
    return data


@app.get("/api/tides/stations")
def api_get_tide_stations():
    stations = get_all_predefined_stations()
    return {
        "status": "success",
        "stations": stations,
        "count": len(stations),
        "api_key_configured": bool(get_worldtides_api_key())
    }


@app.get("/api/tides/config")
def api_get_tides_config():
    key = get_worldtides_api_key()
    masked = f"{key[:4]}...{key[-4:]}" if key and len(key) >= 8 else None
    return {
        "status": "success",
        "api_key_configured": bool(key),
        "masked_key": masked,
        "mode": "live_api" if key else "harmonic_fallback",
        "message": "Live WorldTides API key is permanently active." if key else "Astronomical harmonic tidal model active."
    }


@app.post("/api/tides/config")
def api_set_tides_config(body: TideConfigBody):
    key = body.api_key.strip()
    set_worldtides_api_key(key, persist=True)
    test_res = test_worldtides_connection() if key else {"success": False, "live_test_passed": False}
    return {
        "status": "success",
        "api_key_configured": bool(get_worldtides_api_key()),
        "live_test": test_res,
        "message": "WorldTides API key saved permanently to server environment."
    }


# =============================================================================
# AI MARITIME THREAT RISK PREDICTION
# =============================================================================
@app.post("/api/threats/ai-predict")
def api_predict_risk(body: RiskPredictBody):
    if not AI_AVAILABLE:
        return {
            "status": "fallback",
            "risk_score": 5.0,
            "threat_level": "ELEVATED",
            "message": "AI Scikit-Learn model package optional"
        }
    try:
        score = predict_risk(body.latitude, body.longitude, body.distance_to_coast_km, body.vessel_speed_knots)
        return {
            "status": "success",
            "risk_score": round(score, 2),
            "threat_level": "CRITICAL" if score >= 8.0 else ("HIGH" if score >= 6.0 else ("MEDIUM" if score >= 4.0 else "LOW"))
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8080)
